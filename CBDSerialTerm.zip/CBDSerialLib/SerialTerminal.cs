﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;

namespace CBDSerialLib
{

    /// <summary>
    /// Represents a serial terminal for communication with a serial port.
    /// </summary>
    public class SerialTerminal : IDisposable
    {
        private SerialPort _serialPort;
        private Thread _readThread;
        private bool _continue;

        /// <summary>
        /// Gets the list of supported baud rates.
        /// </summary>
        public static List<int> BaudRates { get; } = new List<int> { 9600, 19200, 38400, 57600, 115200 };

        /// <summary>
        /// Gets the array of available port names.
        /// </summary>
        public static string[] PortNames => SerialPort.GetPortNames();

        /// <summary>
        /// Occurs when data is received from the serial port.
        /// </summary>
        public event EventHandler<string>? DataReceived;

        /// <summary>
        /// Occurs when data is sent to the serial port.
        /// </summary>
        public event EventHandler<string>? DataSent;

        /// <summary>
        /// Occurs when an exception is thrown during serial communication.
        /// </summary>
        public event EventHandler<Exception>? Excepted;

        /// <summary>
        /// Initializes a new instance of the <see cref="SerialTerminal"/> class with the specified serial port settings.
        /// </summary>
        /// <param name="portName">The name of the serial port.</param>
        /// <param name="baudRate">The baud rate.</param>
        /// <param name="parity">The parity.</param>
        /// <param name="dataBits">The number of data bits.</param>
        /// <param name="stopBits">The stop bits.</param>
        /// <param name="handshake">The handshake protocol.</param>
        /// <param name="readTimeout">The read timeout in milliseconds.</param>
        /// <param name="writeTimeout">The write timeout in milliseconds.</param>
        /// <param name="rtsEnabled">A value indicating whether the Request to Send (RTS) signal is enabled.</param>
        /// <param name="dtrEnabled">A value indicating whether the Data Terminal Ready (DTR) signal is enabled.</param>
        public SerialTerminal(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits, Handshake handshake, int readTimeout, int writeTimeout, bool rtsEnabled, bool dtrEnabled)
        {
            _serialPort = new SerialPort
            {
                PortName = portName,
                BaudRate = baudRate,
                Parity = parity,
                DataBits = dataBits,
                StopBits = stopBits,
                Handshake = handshake,
                ReadTimeout = readTimeout,
                WriteTimeout = writeTimeout,
                RtsEnable = rtsEnabled,
                DtrEnable = dtrEnabled
            };

            _readThread = new Thread(Read);
        }

        /// <summary>
        /// Opens the serial port for communication.
        /// </summary>
        /// <exception cref="Exception">Thrown when failed to open the serial port.</exception>
        public void Open()
        {
            try
            {
                if (_readThread.ThreadState == ThreadState.Stopped)
                {
                    _readThread = new Thread(Read);
                }

                if (!_serialPort.IsOpen)
                {
                    _serialPort.Open();
                    _continue = true;

                    if (_readThread.ThreadState == ThreadState.Unstarted && !_readThread.IsAlive)
                    {
                        _readThread.Start();
                    }
                }

                if (!_serialPort.IsOpen)
                {
                    throw new Exception("Failed to open serial port.");
                }
            }
            catch (Exception err)
            {
                OnExceptioned(err);
                throw; // Rethrow the exception to preserve stack trace
            }
        }

        /// <summary>
        /// Gets a value indicating whether the serial port is open.
        /// </summary>
        public bool IsOpen => _serialPort.IsOpen;

        /// <summary>
        /// Closes the serial port.
        /// </summary>
        public void Close()
        {
            try
            {
                _continue = false;

                if (_readThread.ThreadState != ThreadState.Stopped && _readThread.IsAlive)
                {
                    _readThread.Join();
                }

                if (_serialPort.IsOpen)
                {
                    _serialPort.Close();
                }
            }
            catch (Exception err)
            {
                OnExceptioned(err);
                throw; // Rethrow the exception to preserve stack trace
            }
        }

        /// <summary>
        /// Writes the specified message to the serial port.
        /// </summary>
        /// <param name="message">The message to write.</param>
        /// <exception cref="Exception">Thrown when trying to write to a closed serial port.</exception>
        public void Write(string message)
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    _serialPort.WriteLine(message);
                    OnDataSent(message);
                }
                else
                {
                    throw new Exception("Trying to write to closed serial port.");
                }
            }
            catch (Exception err)
            {
                OnExceptioned(err);
                throw; // Rethrow the exception to preserve stack trace
            }
        }

        private void Read()
        {
            try
            {
                while (_continue)
                {
                    if (_serialPort.IsOpen)
                    {
                        if (_serialPort.BytesToRead > 0)
                        {
                            try
                            {
                                var message = _serialPort.ReadLine();
                                OnDataReceived(message);
                            }
                            catch (TimeoutException) { }
                        }
                        else
    
